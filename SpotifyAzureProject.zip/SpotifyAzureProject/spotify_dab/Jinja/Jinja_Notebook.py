# Databricks notebook source
parameters = [


    {
        "table" : "spotify_cata.silver.factstream",  # 表的完整名字
        "alias" : "factstream", #表的简称，方便 join 时写
        "cols" : "factstream.stream_id, factstream.listen_duration"
    },


    {
        "table" : "spotify_cata.silver.dimuser",  
        "alias" : "dimuser", 
        "cols" : "dimuser.user_id, dimuser.user_name",
        "condition" : "factstream.user_id = dimuser.user_id"
    },
    

    {
        "table" : "spotify_cata.silver.dimtrack",  
        "alias" : "dimtrack", 
        "cols" : "dimtrack.track_id, dimtrack.track_name",
        "condition": "factstream.track_id = dimtrack.track_id"
    }
    
   
        
]

# COMMAND ----------

pip install jinja2

# COMMAND ----------

from jinja2 import Template #导入 Jinja2 模板工具，用来根据配置 → 自动生成 SQL 代码。

# COMMAND ----------

query_text = """
        SELECT
            {% for param in parameters %}
                {{ param.cols }}
                    {% if not loop.last %}
                    ,
                    {% endif %}
            {% endfor %}
        FROM 
            {% for param in parameters %}      
                {% if loop.first %}
                    {{param.table}} AS {{param.alias}}
                {% endif %}
            {% endfor %}

            {% for param in parameters %}      
                {% if not loop.first %}
                LEFT JOIN 
                    {{param.table}} AS {{param.alias}}
                ON
                    {{param.condition}}
                {% endif %}
                
            {% endfor %}


"""

# COMMAND ----------

jinja_sql_str = Template(query_text) #把普通字符串转换成模板对象，让它支持变量、循环、判断语法
query = jinja_sql_str.render(parameters = parameters) 
#把 parameters 配置数据，填充到提前写好的 SQL 模板里，自动拼接出完整可运行的 SQL 语句，结果存入变量 query。
print(query) #打印最终拼接好的 SQL 文本，方便查看、调试

# COMMAND ----------

# DBTITLE 1,Cell 6
spark.sql(query) #执行字符串形式的 SQL 语句，返回查询结果数据集。

# COMMAND ----------

display(spark.sql(query))