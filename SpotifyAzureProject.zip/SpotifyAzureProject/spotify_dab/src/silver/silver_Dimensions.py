# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

import os
import sys
current_path = os.getcwd() #获取你当前所在的文件夹路径
spotify_dab_path = os.path.abspath(os.path.join(current_path, "..", "..")) #：从当前子目录跳回项目根目录 spotify_dab
print(spotify_dab_path)

sys.path.append(spotify_dab_path)
from utils.transformations import reusable

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimUser**

# COMMAND ----------

df = spark.read \
    .format("parquet") \
    .load("abfss://bronze@zzxazureproject.dfs.core.windows.net/DimUser")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Autoloader**

# COMMAND ----------

# DBTITLE 1,Cell 6
# 使用 Auto Loader 持续增量读取 DimUser
# 我要持续、自动、增量读取 bronze 里的 DimUser 数据，新文件来了自动读，结构变了自动适应，永不重复处理。
df_user = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "parquet") \
    .option("cloudFiles.schemaLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimUser/schema") \
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns") \
    .load("abfss://bronze@zzxazureproject.dfs.core.windows.net/DimUser")

# COMMAND ----------

# DBTITLE 1,Cell 7
query_user = (df_user.writeStream
    .format("memory")
    .queryName("df_user_preview")
    .outputMode("append")
    .trigger(availableNow=True)
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimUser/checkpoint_display")
    .start())
query_user.awaitTermination()
display(spark.sql("SELECT * FROM df_user_preview LIMIT 10"))

# COMMAND ----------

df_transformed = df_user.withColumn("user_name" , upper(col("user_name")))

# COMMAND ----------

# DBTITLE 1,Cell 10
df_user_obj = reusable()

df_transformed = df_user_obj.dropColumns(df_transformed, ['_rescued_data'])
df_transformed = df_transformed.dropDuplicates(['user_id'])


# COMMAND ----------

query_transformed = (df_transformed.writeStream
    .format("memory")
    .queryName("df_transformed_preview")
    .outputMode("append")
    .trigger(availableNow=True)
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimUser/checkpoint_display_transformed_cell10")
    .start())
query_transformed.awaitTermination()
display(spark.sql("SELECT * FROM df_transformed_preview LIMIT 10"))

# COMMAND ----------

# DBTITLE 1,Cell 12
(df_transformed.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimUser/checkpoint")
    .trigger(once=True)
    .option("path", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimUser/data")\
    .toTable("spotify_cata.silver.DimUser"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimArtist**
# MAGIC

# COMMAND ----------

df_art = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "parquet") \
    .option("cloudFiles.schemaLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimArtist/schema") \
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns") \
    .load("abfss://bronze@zzxazureproject.dfs.core.windows.net/DimArtist")

# COMMAND ----------

query_user = (df_art.writeStream
    .format("memory")
    .queryName("df_artist_preview")
    .outputMode("append")
    .trigger(availableNow=True)
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimArtist/checkpoint_display")
    .start())
query_user.awaitTermination()
display(spark.sql("SELECT * FROM df_artist_preview LIMIT 10"))

# COMMAND ----------

df_art_obj = reusable()

df_art = df_art_obj.dropColumns(df_art, ['_rescued_data'])
df_art = df_art.dropDuplicates(['artist_id'])


# COMMAND ----------

(df_art.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimArtist/checkpoint")
    .trigger(once=True)
    .option("path", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimArtist/data")\
    .toTable("spotify_cata.silver.DimArtist"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimTrack**
# MAGIC

# COMMAND ----------

df_tra = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "parquet") \
    .option("cloudFiles.schemaLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimTrack/schema") \
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns") \
    .load("abfss://bronze@zzxazureproject.dfs.core.windows.net/DimTrack")


query_user = (df_tra.writeStream
    .format("memory")
    .queryName("df_tra_preview")
    .outputMode("append")
    .trigger(availableNow=True)
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimTrack/checkpoint_display")
    .start())
query_user.awaitTermination()
display(spark.sql("SELECT * FROM df_tra_preview LIMIT 100"))

# COMMAND ----------

df_tra = df_tra.withColumn("durationFlag" , when(col('duration_sec')<=150, "low")\
    .when(col('duration_sec')<=300, "medium")\
    .otherwise("high"))

df_tra = df_tra.withColumn("track_name", regexp_replace(col("track_name"),'-', ' '))

df_tra_obj = reusable()

df_tra = df_tra_obj.dropColumns(df_tra, ['_rescued_data'])
df_tra = df_tra.dropDuplicates(['track_id'])



# COMMAND ----------


query_user = (df_tra.writeStream
    .format("memory")
    .queryName("df_tra_preview")
    .outputMode("append")
    .trigger(availableNow=True)
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimTrack/checkpoint_display_cell20")
    .start())
query_user.awaitTermination()
display(spark.sql("SELECT * FROM df_tra_preview LIMIT 10"))

# COMMAND ----------

(df_tra.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimTrack/checkpoint")
    .trigger(once=True)
    .option("path", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimTrack/data")\
    .toTable("spotify_cata.silver.DimTrack"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimDate**
# MAGIC

# COMMAND ----------

df_dat = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "parquet") \
    .option("cloudFiles.schemaLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimDate/schema") \
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns") \
    .load("abfss://bronze@zzxazureproject.dfs.core.windows.net/DimDate")

# COMMAND ----------

df_dat_obj = reusable()

df_dat = df_dat_obj.dropColumns(df_dat, ['_rescued_data'])



# COMMAND ----------

(df_dat.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimDate/checkpoint")
    .trigger(once=True)
    .option("path", "abfss://silver@zzxazureproject.dfs.core.windows.net/DimDate/data")\
    .toTable("spotify_cata.silver.DimDate"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## **FactStream**
# MAGIC

# COMMAND ----------

df_fact = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "parquet") \
    .option("cloudFiles.schemaLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/FactStream/schema") \
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns") \
    .load("abfss://bronze@zzxazureproject.dfs.core.windows.net/FactStream")

query_user = (df_fact.writeStream
    .format("memory")
    .queryName("df_fact_preview")
    .outputMode("append")
    .trigger(availableNow=True)
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/FactStream/checkpoint_display")
    .start())
query_user.awaitTermination()
display(spark.sql("SELECT * FROM df_fact_preview LIMIT 10"))

# COMMAND ----------

df_fact_obj = reusable()

df_fact = df_fact_obj.dropColumns(df_fact, ['_rescued_data'])



# COMMAND ----------

(df_fact.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation", "abfss://silver@zzxazureproject.dfs.core.windows.net/FactStream/checkpoint")
    .trigger(once=True)
    .option("path", "abfss://silver@zzxazureproject.dfs.core.windows.net/FactStream/data")\
    .toTable("spotify_cata.silver.FactStream"))